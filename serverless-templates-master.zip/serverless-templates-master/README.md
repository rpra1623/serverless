# serverless-templates
Project and CloudFormation templates to quickly start building serverless applications
